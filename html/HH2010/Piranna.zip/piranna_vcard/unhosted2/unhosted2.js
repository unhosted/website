function CONTENT(nick,fullpath)
{
	var keys = JSON.parse(unhosted.get(nick, fullpath));
    if(!keys) keys = {};

    return keys;
}


function unhosted_get(nick, app, key, value)
// Get a value from the datastore if access is granted.
// If no data is gotten and value is defined it's returned as default.
{
	function Get(key,value)
	{
	    function Get2(key,value)
	    {
		    // If webapp has access capability,
		    // return it's value (or defined default)
		    if(KEYS_get(nick, app, key, 'get'))
		    {
			    // Get key value
			    unhosted.importSub(PasswordMe, nick);
			    return unhosted.get(nick, key);
		    }

		    // Webapp is not registered
		    // or don't have access to that key
		    // or key is not set
		    if(value!=undefined)
			    return value;
		    return undefined;
		}

	    // Get sub-content
	    if(key[key.length-1]=='/')
	    {
	        var ret = {};

	        var content = CONTENT(nick,key)
            for(var c in content)
                ret[c] = Get2(key+c,value);

	        return ret;
	    }

        return Get2(key,value);
	}

	if(key instanceof Array)
	{
		var ret = Array();
		for(var k in key)
			if(value instanceof Array)
				ret[k] = Get(key[k],value[k]);
			else
				ret[k] = Get(key[k],value);
		return ret;
	}
	else
		return Get(key,value);
}


function unhosted_set(nick, app, key, value)
// Set a value in the datastore if access is granted.
{
	function Set(key,value)
	{
		unhosted.importPub(PasswordMe, nick);

        // Generate path keys (if any)
	    var path = key.split('/')
	    var offset = path[path.length-1]?1:2
	    if(path.length > offset)
	    {
	        // Generate path
	        var fullpath = "";
	        for(var p=0; p<(path.length-offset); p++)
                fullpath += path[p]+'/';

            // Get content of the path and add new entry
	        var content = CONTENT(nick,fullpath)
            content[path[path.length-offset]] = null;

            // Set path key
            unhosted_set(nick, app, fullpath, JSON.stringify(content));
	    }

		// If app has the set capability over the key,
		// set the key-value pair
		if(KEYS_get(nick, app, key, 'set', true))
			unhosted.set(nick, key, value);
	};

	// If key and value are arrays, set them one-by-one
	if(key instanceof Array)
	{
		for(var k in key)
			if(value instanceof Array)
				Set(key[k],value[k]);
			else
				Set(key[k],value);
	}
	else
		Set(key,value);
}

