function Webapp_Add(nick, app)
{
	var apps = APPS(nick);
	if(apps[app]==undefined)
    {
	    // Generate webapp id getting (or recicling)
	    // the first non-used id from the webapps id dict
	    var ids = [];
	    for(var ap in apps)
		    ids.push(apps[ap]);
	    ids = ids.sort(function(a,b){return a-b;});

	    var id=0;
	    for(; id < ids.length; id++)
		    if(ids[id] > id)
			    break;

	    if(id >= 32)	// Security thread for current implementation
		    throw("You can't use more than 32 webapps at this moment.");

	    apps[app] = id;

	    unhosted.importPub(PasswordMe, nick)
	    unhosted.set(nick, ".webapps", JSON.stringify(apps))

	    // Delete old capabilites for new id
	    var keys = KEYS(nick);
	    if(keys)
	    {
		    var caps = ['del','get','set'];

		    for(var key in keys)
			    for(var cap in caps)
				    keys[key][caps[cap]] &= ~(1 << id);

		    unhosted.set(nick, ".capabilities", JSON.stringify(keys))
	    }
	}

	return apps[app];
}



function Webapp_Del(nick, app)
// Del a webapp from the datastore access control system.
{
	// Get webapps
	var apps = APPS(nick);

	// Delete webapp id (recicle it)
	delete apps[app];

	// Store webapps
	unhosted.importPub(PasswordMe, nick)
	unhosted.set(nick, ".webapps", JSON.stringify(apps))
}


function APPS(nick)
// Get a list of all apps registered in the datastore for that nick.
{
	var apps = JSON.parse(unhosted.get(nick, ".webapps"));
    if(!apps) apps = {};

    return apps;
}


function KEYS(nick)
// Get a list of all keys in the datastore and it's capabilies for that nick.
{
	var keys = JSON.parse(unhosted.get(nick, ".capabilities"));
    if(!keys) keys = {};

    return keys;
}


function KEYS_get(nick, app, key, cap, value)
{
	// Get webapp id and add it if it was not registered
	var mask = 1 << Webapp_Add(nick, app);

	var keys = KEYS(nick)
	if(keys[key])
        return keys[key][cap] & mask;

    else if(value)
    {
        KEYS_set(nick, app, key, ['del','get','set'], mask);
        return true;
    }

    else
        return false;
}


function KEYS_set(nick, app, key, cap, value)
// Set the capability of a key-value pair from the datastore.
{
	// Get webapps and capabilities
	var apps = APPS(nick)
	var keys = KEYS(nick)

	var mask = 1 << apps[app]

    function Set_Key(key,cap,value)
    {
        function Set_Cap(cap,value)
        {
            if(!keys[key])
                keys[key] = {};

	        if(value)
		        keys[key][cap] |= mask;
	        else
		        keys[key][cap] &= ~mask;
	    }

	    if(cap instanceof Array)
	    {
		    for(var c in cap)
			    if(value instanceof Array)
				    Set_Cap(cap[c],value[c]);
			    else
				    Set_Cap(cap[c],value);
	    }
	    else if(value instanceof Array)
		    throw "Value is an Array, but cap don't.";
	    else
		    Set_Cap(cap,value);
	}

	if(key instanceof Array)
	{
		for(var k in key)
			if(cap instanceof Array)
				Set_Key(key[k],cap[k],value);
			else
				Set_Key(key[k],cap,value);
	}
	else
		Set_Key(key,cap,value);

	// Store capabilities
	unhosted.importPub(PasswordMe, nick)
	unhosted.set(nick, ".capabilities", JSON.stringify(keys))
}

