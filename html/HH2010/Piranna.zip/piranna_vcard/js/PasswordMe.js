//r is for Read Caps, and it's simply like the username, the part before the '@'-sign in an unhosted address
//c is for Cloud, the domain name of the unhosted server
//n is RSA's name for the public key (e=0x10001). Ever heard of RSA being large primes multiplied? There you go: n=p*q.
//s is for session key. Again, RSA terminology. It's the access token you share to a groud of friends or subscribers
//w is for Write Caps, it's your (weakish) login password at the unhosted server where you have your account 'r@c'.
//d is RSA's name for the private key. d is such that d*e=1 in MOD (p-1)(q-1). The maths is done by Tom Wu's jsbn lib.
var PasswordMe = {
	"r":"7db31",
	"c":"example.unhosted.org",
	"n":"6cc083ab24d4f76d157ff761bce944f840f84d37e9eae89caeef7e4807661dbb17417603e9c1b1c7b6287b64c6087aa30b65205c55cc6173b5a822141c3f626b",
	"s":"f0e9955287a1660e23bec8814919b9f1",
	"w":"0249e",
	"d":"650cfd4ba98db9dac27f857e6bead50b5853606cf40e32d664366540c89f3a3fc5efd7ddc3279b605d66898bb2e7b1c9fe8621065d158a10e89ab4a94cfd801"};