function To_N(n)
{
	return n['familyName']+';'+n['givenName']+';'+n.aditionalName+';'+n.honorificPrefix+';'+n.honorificSuffix;
}


function To_FN(n)
{
	return n.honorificPrefix+' '+n.givenName+' '+n.aditionalName+' '+n.familyName+' '+n.honorificSuffix;
}


function Render_VCard(app)
{
	unhosted.importSub(PasswordMe, "hardCodedSub")

	var vcard = "BEGIN:VCARD\nVERSION:3.0\n";

	var n = unhosted_get("hardCodedSub", app, "N/");
//for(var a in n)
//    alert(a+" "+n[a]);
	if(n)
	{
		vcard += "N:" +To_N(n)	+"\n";
		vcard += "FN:"+To_FN(n)	+"\n";
	}

	var nickname = unhosted_get("hardCodedSub", app, "NICKNAME");
	if(nickname)
		vcard += "NICKNAME:"+nickname+"\n"

	var org = unhosted_get("hardCodedSub", app, "ORG");
	if(org)
		vcard += "ORG:"+org+"\n"

	var title = unhosted_get("hardCodedSub", app, "TITLE");
	if(title)
		vcard += "TITLE:"+title+"\n";

	vcard += "END:VCARD";

    return vcard;
}

