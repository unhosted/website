function Load_VCard()
{
	unhosted.importSub(PasswordMe, "hardCodedSub");

	document.getElementById("N/honorificPrefix").value = unhosted_get("hardCodedSub","editor","N/honorificPrefix","");
	document.getElementById("N/givenName").value       = unhosted_get("hardCodedSub","editor","N/givenName","");
	document.getElementById("N/aditionalName").value   = unhosted_get("hardCodedSub","editor","N/aditionalName","");
	document.getElementById("N/familyName").value      = unhosted_get("hardCodedSub","editor","N/familyName","");
	document.getElementById("N/honorificSuffix").value = unhosted_get("hardCodedSub","editor","N/honorificSuffix","");


	document.getElementById("ADR/poBox").value	         = unhosted_get("hardCodedSub","editor","ADR/poBox","");
	document.getElementById("ADR/extendedAddress").value = unhosted_get("hardCodedSub","editor","ADR/extendedAddress","");
	document.getElementById("ADR/streetAddress").value   = unhosted_get("hardCodedSub","editor","ADR/streetAddress","");
	document.getElementById("ADR/locality").value	     = unhosted_get("hardCodedSub","editor","ADR/locality","");
	document.getElementById("ADR/region").value	         = unhosted_get("hardCodedSub","editor","ADR/region","");
	document.getElementById("ADR/postalCode").value	     = unhosted_get("hardCodedSub","editor","ADR/postalCode","");
	document.getElementById("ADR/countryName").value	 = unhosted_get("hardCodedSub","editor","ADR/countryName","");

	document.getElementById("NICKNAME").value = unhosted_get("hardCodedSub","editor","NICKNAME","");
	document.getElementById("ORG").value	  = unhosted_get("hardCodedSub","editor","ORG","");
	document.getElementById("TITLE").value	  = unhosted_get("hardCodedSub","editor","TITLE","");
}


function Store_VCard()
{
	unhosted.importPub(PasswordMe, "hardCodedPub");

	unhosted_set("hardCodedPub","editor",
				["N/honorificPrefix","N/givenName","N/aditionalName","N/familyName","N/honorificSuffix",
				"ADR/poBox","ADR/extendedAddress","ADR/streetAddress","ADR/locality","ADR/region","ADR/postalCode","ADR/countryName",
				"NICKNAME","ORG","TITLE"],
				[document.getElementById("N/honorificPrefix").value,
                 document.getElementById("N/givenName").value,
                 document.getElementById("N/aditionalName").value,
                 document.getElementById("N/familyName").value,
                 document.getElementById("N/honorificSuffix").value,

                 document.getElementById("ADR/poBox").value,
                 document.getElementById("ADR/extendedAddress").value,
                 document.getElementById("ADR/streetAddress").value,
                 document.getElementById("ADR/locality").value,
                 document.getElementById("ADR/region").value,
                 document.getElementById("ADR/postalCode").value,
                 document.getElementById("ADR/countryName").value,

				 document.getElementById("NICKNAME").value,
				 document.getElementById("ORG").value,
				 document.getElementById("TITLE").value]);
}

