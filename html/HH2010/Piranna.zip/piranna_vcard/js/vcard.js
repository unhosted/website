function Get_Params()
// Get the parameters of the page as an object
{
    var ret = {};

    var params = location.search.substring(1).split('&');
    for(var i=0; i<params.length; i++)
    {
        params[i] = params[i].split('=');
        ret[unescape(params[i][0])] = unescape(params[i][1]);
    };

    return ret;
}


function Load_VCard()
{
	document.write(Render_VCard(Get_Params()['app']));
}

