function Load_Capabilities()
{
	var table = document.getElementById("capabilities");
//	    table.border = 1;

	// Table header (webapps)
	var tr = document.createElement("TR");
	table.appendChild(tr);

	// First empty top-left cell
	tr.appendChild(document.createElement("TH"));

	// Webapps
	var caps = ['del','get','set'];

	unhosted.importPub(PasswordMe,'hardCodedSub');
	var apps = APPS("hardCodedSub");
	for(var app in apps)
	{
		var td = document.createElement("TH");
			td.appendChild(document.createTextNode(app));
			td.colSpan = caps.length;
		tr.appendChild(td);
	}

	// Table header (capabilities)
	tr = document.createElement("TR");
	table.appendChild(tr);

	// Second empty top-left cell
	tr.appendChild(document.createElement("TH"));

	// Capabilities
	for(var app in apps)
		for(var cap in caps)
		{
			var td = document.createElement("TH");
				td.appendChild(document.createTextNode(caps[cap]));
			tr.appendChild(td);
		};

	// Table content
	var keys = KEYS("hardCodedSub")
	for(var key in keys)
	{
		// Row
		var tr = document.createElement("TR");
		table.appendChild(tr);

        if(key[key.length-1]=='/')
            tr.style.backgroundColor="orange";

		// Keys
		var th = document.createElement("TD");
		tr.appendChild(th);

//		unhosted.importSub(PasswordMe, "hardCodedSub")
//		var value = "("+unhosted_get("hardCodedSub", , cap)+")"

		th.appendChild(document.createTextNode(key));
//		th.appendChild(document.createElement("BR"));
//		th.appendChild(document.createTextNode(value));

		// Capabilities
		for(var app in apps)
		{
			for(var cap in keys[key])
			{
				var td = document.createElement("TD");
				tr.appendChild(td);

				var input = document.createElement("INPUT");
					input.type = "checkbox";
					input.checked = keys[key][cap] & (1 << apps[app]);

					input.app = app;
					input.key = key;
					input.cap = cap;

					input.onclick = function()
					{
						unhosted.importPub(PasswordMe,'hardCodedPub');
						KEYS_set("hardCodedPub",
								this.app, this.key, this.cap, this.value);
					};

				td.appendChild(input);
			}
		}
	}
}

