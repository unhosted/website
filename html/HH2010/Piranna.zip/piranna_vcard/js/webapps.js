function Load_Webapps()
{
	// Remove old webapps list
	var webapps = document.getElementById("webapps");
	while(webapps.hasChildNodes())
		webapps.removeChild(webapps.firstChild);

	// Get webapps
	unhosted.importSub(PasswordMe, "hardCodedSub");

	for(var app in APPS("hardCodedSub"))
	{
		var li = document.createElement("LI");
		webapps.appendChild(li);

		li.appendChild(document.createTextNode(app));
		var input = document.createElement("INPUT");
			input.id = app;
			input.onclick = function()
			{
				Webapp_Del("hardCodedPub", this.id);
				Load_Webapps();
			};
			input.type = "button";
			input.value = "Del webapp";
		li.appendChild(input);
	}
}