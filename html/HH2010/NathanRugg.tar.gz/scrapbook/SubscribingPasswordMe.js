//r is for Read Caps, and it's simply like the username, the part before the '@'-sign in an unhosted address
//c is for Cloud, the domain name of the unhosted server
//n is RSA's name for the public key (e=0x10001). Ever heard of RSA being large primes multiplied? There you go: n=p*q.
//s is for session key. Again, RSA terminology. It's the access token you share to a groud of friends or subscribers
var SubscribingPasswordMe = {
	"r":"7db31",
	"c":"example.unhosted.org",
	"n":"ddf563c24da318727b060307da3ace0c46e357c81d3137d79f2bf1125ec240980aa5d7aaa963a61028cb876416a181654ed6996cd9bb40449b0bd88eb8e42ce7",
	"s":"c6f7e7612b256f7a943fa45e72b56dcd"
};
