
//r is for Read Caps, and it's simply like the username, the part before the '@'-sign in an unhosted address
//c is for Cloud, the domain name of the unhosted server
//n is RSA's name for the public key (e=0x10001). Ever heard of RSA being large primes multiplied? There you go: n=p*q.
//s is for session key. Again, RSA terminology. It's the access token you share to a groud of friends or subscribers
//w is for Write Caps, it's your (weakish) login password at the unhosted server where you have your account 'r@c'.
//d is RSA's name for the private key. d is such that d*e=1 in MOD (p-1)(q-1). The maths is done by Tom Wu's jsbn lib.
var PublishingPasswordMe = {
	"r":"7db31",
	"c":"example.unhosted.org",
	"n":"d6e7cce47826b7ed2dc9c84025875ac0d84ef42e84cb3a0e1a1eba5736d89ae724a92f51931d5fe48495b8605633a1e24ae1ad35cc5f05d5114cc0bbad2b999f",
	"s":"f3cd4e5d435cf5c2e462863f7642f577",
	"w":"0249e",
	"d":"5e234419809855514c116beacd85b137708985652b3e6abbeaad332b29175122c9dff9e3a4fff23b77aaf2f033e14152dc359678685f8875d7f0d31bb5332781"};

