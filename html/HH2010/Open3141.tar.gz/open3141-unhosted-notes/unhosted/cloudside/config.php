<?php
$GLOBALS['dbHost'] = 'localhost';
$GLOBALS['dbUser'] = 'root';
$GLOBALS['dbPwd'] = 'password';
$GLOBALS['dbName'] = 'unhosted1';
//uncomment this if you're on OSX:
// $GLOBALS['dbSock'] = '/tmp/mysql.sock';
?>
