
/* notes.js - a simple note system using UNHOSTED UJ/0.1
 * by Jack Bowman - 1 Jan 2011
 * (Submission for the Hacky Holidays contest.)
 *
 * No mechanism is provided for login - we assume that
 * there are the "*PasswordMe.js" files like in the examples.
 */


// TODO:
// - drag and drop to change order of notes
// - export ability
// - some kind of login
// - options page


var currentNick = "";
var curPub = "pub";
var curSub = "sub";

var notes = new Array();
var infos = {}; // .list is an [] of NoteInfo

var modifiedNotes = new Array();
var saveTimeout = -1;
var saveTimeoutMS = 8000;

var lastNoteID = "";

// a class to store basic information about each note
function Note(id, title, d) {
  this.id = id;
  this.title = title;
  this.createdDate = d;
  this.modifiedDate = d;
  this.text = "";
  this.modified = false; // if true then we are in "modifiedNotes"
  this.elem = generateNoteElem(this);
};

function NoteInfo(id, title) {
  this.id = id;
  this.title = title;
};

// returns the div element associated with a given note
function getNoteElem(note) {
  return document.getElementById("n-"+note.id);
};

// updates a note
function updateNote(note) {
  var elem = getNoteElem(note);
  for (j in elem.childNodes) {
    var c = elem.childNodes[j];
    if (c.className == "note-title-edit") {
      note.title = c.value;
    }
    else if (c.className == "note-text") {
      note.text = c.value;
    }
  }
};

// this function is called every 5 seconds
// and saves all of the modified notes
function saveTimer() {
  for (i in modifiedNotes) {
    var note = modifiedNotes[i];
    updateNote(note);
    note.modified = false;
    saveNote(note);
  }
  modifiedNotes = new Array();
  window.setTimeout("saveTimer();", saveTimeoutMS);
};

function setNoteModified(note) {
  if(!note.modified) {
    note.modified = true;
    modifiedNotes.push(note);
  }
};

function deleteNote(note) {
  //alert("Deleting note with title: "+note.title);
  unhosted.set(curPub, note.id, null);
  for (i in infos.list) {
    if (infos.list[i].id == note.id) {
      infos.list.splice(i,1);
    }
  }
  saveList();
  notes.splice(notes.indexOf(note),1);
};

function loadNoteList() {
  infos = unhosted.get(curSub, "noteslist");
  // need to handle no note info existing yet
  if(infos == null || infos.list == undefined) {
    infos = {};
    infos.list = new Array();
  }
};

// Retrieve each note referenced in "infos.list"
function populateNotes() {
  notes = new Array();
  for (i in infos.list) {
    var n = unhosted.get(curSub, infos.list[i].id);
    if (n != null) {
      n.modified = false;
      // the dates aren't "Date"s after being retrieved?
      // so we have to remake them
      n.createdDate = new Date(n.createdDate);
      n.modifiedDate = new Date(n.modifiedDate);
      n.elem = generateNoteElem(n);
      notes.push(n);
    }
    else {
      alert("Error retrieving note from "+infos.list[i].id + ". Removing from notes.");
      infos.list.splice(i,1);
    }
  }
};


// store the given note using unhosted
function saveNote(note) {
  var temp = note.elem;
  note.modifiedDate = new Date();
  note.elem = null;
  unhosted.set(curPub, note.id, note);
  note.elem = temp;
};

// store the list of notes using unhosted
function saveList() {
  unhosted.set(curPub, "noteslist", infos);
};

// initialize unhosted stuff
function initPubSub(pub, sub, name) {
  currentNick = name;
  curPub = name + "pub";
  curSub = name + "sub";
  unhosted.importPub(pub, curPub);
  unhosted.importSub(sub, curSub);
};

function generateNoteElem(note) {
  var noteDivElem = document.createElement('div');
  noteDivElem.setAttribute('class', 'note');
  noteDivElem.setAttribute('id', "n-" + note.id);
  noteDivElem.myNote = note;
  var titleTextElem = document.createElement('div');
  titleTextElem.setAttribute('class', 'note-title-text');
  titleTextElem.setAttribute('onclick', 'toggleEditTitle(this.parentNode);');
  titleTextElem.appendChild(document.createTextNode(note.title));
  var titleInputElem = document.createElement('input');
  titleInputElem.setAttribute('type', 'text');
  titleInputElem.setAttribute('class', 'note-title-edit');
  titleInputElem.setAttribute('style', 'display: none');
  titleInputElem.setAttribute('value', note.title);
  titleInputElem.setAttribute('onKeyPress',
        'setNoteModified(this.parentNode.myNote); inputResize(this);');
  titleInputElem.setAttribute('onBlur', 'toggleEditTitle(this.parentNode);');
  var deleteButtonElem = document.createElement('input');
  deleteButtonElem.setAttribute('type', 'submit');
  deleteButtonElem.setAttribute('class', 'delete-button');
  deleteButtonElem.setAttribute('value', "x");
  deleteButtonElem.setAttribute('onclick', 'deleteNoteByDiv(this.parentNode);');
  var expandButtonElem = document.createElement('div');
  expandButtonElem.setAttribute('class', 'expand-button');
  expandButtonElem.setAttribute('onclick', 'toggleExpand(this.parentNode);');
  expandButtonElem.appendChild(document.createTextNode("[+]"));
  var textAreaElem = document.createElement('textarea');
  textAreaElem.setAttribute('class', 'note-text');
  textAreaElem.setAttribute('style', 'display: none');
  textAreaElem.setAttribute('onKeyPress',
       'setNoteModified(this.parentNode.myNote); textResize(this);');
  textAreaElem.appendChild(document.createTextNode(note.text));
  var dateElem = document.createElement('div');
  dateElem.setAttribute('class', 'date-notice');
  var d = note.createdDate;
  var dateString = " created ";
  dateString += d.getHours()+":";
  if (d.getMinutes() < 10) {
    dateString += "0";
  }
  dateString += d.getMinutes()+" ";
  dateString += d.getDate()+"-"+(d.getMonth()+1)+"-"+d.getFullYear()+" ";
  dateElem.appendChild(document.createTextNode(dateString));

  noteDivElem.appendChild(titleTextElem);
  noteDivElem.appendChild(titleInputElem);
  noteDivElem.appendChild(document.createTextNode(" "));
  noteDivElem.appendChild(expandButtonElem);
  noteDivElem.appendChild(dateElem);
  noteDivElem.appendChild(deleteButtonElem);
  noteDivElem.appendChild(document.createElement('br'));
  noteDivElem.appendChild(textAreaElem);

  return noteDivElem;
};

function addNoteToDisplay(note) {
  var listElem = document.getElementById("notelist");
  listElem.insertBefore(generateNoteElem(note), listElem.firstChild);
};

function refreshListDisplay() {
  var listElem = document.getElementById("notelist");
  // remove all the children of listElem
  while(listElem.hasChildNodes()) {
    listElem.removeChild(listElem.firstChild);
  }

  // now add each note
  for (i in notes) {
    listElem.appendChild(generateNoteElem(notes[i]));
  }
};

function getChildOfClass(elem,cname) {
  for (i in elem.childNodes) {
    var c = elem.childNodes[i];
    if (c.className == cname) {
      return c;
    }
  }
  return null;
};

/*
 * EXPOSED FUNCTIONS:
 */

var makeNewNote = function() {
  var defaultTitle = "New Note";
  var d = new Date();
  var newID = "notes-" + d;
  if (newID == lastNoteID) {
    newID += "1";
  }
  lastNoteID = newID;
  var note = new Note(newID, defaultTitle, new Date());
  var info = new NoteInfo(newID, defaultTitle);
  notes.unshift(note);
  infos.list.unshift(info);

  addNoteToDisplay(note);
  saveNote(note);
  saveList();
};

var deleteNoteByDiv = function(div) {
  div.parentNode.removeChild(div);
  deleteNote(div.myNote);
};

var finalSave = function() {
  for (i in modifiedNotes) {
    var note = modifiedNotes[i];
    updateNote(note);
    saveNote(note);
  }
};

var toggleEditTitle = function(elem) {
  var titleInput = getChildOfClass(elem,"note-title-edit");
  var titleText = getChildOfClass(elem,"note-title-text");
  if (titleInput.style.display == "none") {
    titleText.style.display = "none";
    titleInput.style.display = "inline";
    inputResize(titleInput);
    titleInput.focus();
  }
  else {
    titleInput.style.display = "none";
    titleText.firstChild.nodeValue = titleInput.value;
    titleText.style.display = "inline";
  }
};

var inputResize = function(inputElem) {
  inputElem.size = inputElem.value.length+1;
};

var textResize = function(taElem) {
  //taElem.style.height = (taElem.scrollHeight+10) + "px";
  while (taElem.rows > 1 && taElem.scrollHeight < taElem.offsetHeight) {
    taElem.rows--;
  }
  while (taElem.scrollHeight > taElem.offsetHeight) {
    taElem.rows++;
  }
  taElem.rows++;
};

var doExpand = function(elem) {
  var textArea = getChildOfClass(elem, "note-text");
  var expandButton = getChildOfClass(elem, "expand-button");
  //var deleteButton = getChildOfClass(elem, "delete-button");
  textArea.style.display = "block";
  textResize(textArea);
  //deleteButton.style.display = "inline";
  expandButton.firstChild.nodeValue = "[-]";
};

var doCollapse = function(elem) {
  var textArea = getChildOfClass(elem, "note-text");
  var expandButton = getChildOfClass(elem, "expand-button");
  //var deleteButton = getChildOfClass(elem, "delete-button");
  textArea.style.display = "none";
  //deleteButton.style.display = "none";
  expandButton.firstChild.nodeValue = "[+]";
};

var isCollapsed = function(elem) {
  var expandButton = getChildOfClass(elem, "expand-button");
  return expandButton.firstChild.nodeValue == "[+]";
};

var toggleExpand = function(elem) {
  if (isCollapsed(elem)) {
    doExpand(elem);
  }
  else {
    doCollapse(elem);
  }
};

var expandAll = function() {
  var list = document.getElementById("notelist");
  for (i in list.childNodes) {
    var elem = list.childNodes[i];
    if (elem.className == "note" && isCollapsed(elem)) {
      doExpand(elem);
    }
  }
};

var collapseAll = function() {
  var list = document.getElementById("notelist");
  for (i in list.childNodes) {
    var elem = list.childNodes[i];
    if (elem.className == "note" && !isCollapsed(elem)) {
      doCollapse(elem);
    }
  }
};

var initialize = function() {
  initPubSub(PublishingPasswordMe, SubscribingPasswordMe, "hardCodedNick");
  loadNoteList();
  populateNotes();
  refreshListDisplay();
  saveTimeout = window.setTimeout("saveTimer();", saveTimeoutMS);
};

var reset = function() {
  for (note in notes) {
    unhosted.set(curPub, notes[note].id, null);
  }
  infos = {};
  infos.list = new Array();
  saveList();

  loadNoteList();
  populateNotes();
  refreshListDisplay();
};

