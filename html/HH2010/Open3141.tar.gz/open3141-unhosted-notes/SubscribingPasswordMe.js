//r is for Read Caps, and it's simply like the username, the part before the '@'-sign in an unhosted address
//c is for Cloud, the domain name of the unhosted server
//n is RSA's name for the public key (e=0x10001). Ever heard of RSA being large primes multiplied? There you go: n=p*q.
//s is for session key. Again, RSA terminology. It's the access token you share to a groud of friends or subscribers
var SubscribingPasswordMe = {
	"r":"7db31",
	"c":"example.unhosted.org",
	"n":"d6e7cce47826b7ed2dc9c84025875ac0d84ef42e84cb3a0e1a1eba5736d89ae724a92f51931d5fe48495b8605633a1e24ae1ad35cc5f05d5114cc0bbad2b999f",
	"s":"f3cd4e5d435cf5c2e462863f7642f577"};

