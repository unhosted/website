<?php
OC_App::register( array( 
  'order' => 11,
  'id' => 'user_webfinger',
  'name' => 'Webfinger' ));
