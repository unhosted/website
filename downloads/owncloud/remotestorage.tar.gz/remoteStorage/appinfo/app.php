<?php
OC_App::register( array( 
  'order' => 10,
  'id' => 'remoteStorage',
  'name' => 'remoteStorage compatibility' ));
OC_APP::registerPersonal('remoteStorage','settings');
